import React from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import ROICalculator from './components/ROICalculator';
import Services from './components/Services';
import SuccessStories from './components/SuccessStories';
import Consultation from './components/Consultation';
import FloatingCTA from './components/FloatingCTA';
import CircuitBackground from './components/CircuitBackground';

function App() {
  return (
    <div className="relative min-h-screen bg-primary text-secondary overflow-x-hidden">
      <CircuitBackground />
      <Navigation />
      <main>
        <Hero />
        <ROICalculator />
        <Services />
        <SuccessStories />
        <Consultation />
      </main>
      <FloatingCTA />
    </div>
  );
}

export default App;