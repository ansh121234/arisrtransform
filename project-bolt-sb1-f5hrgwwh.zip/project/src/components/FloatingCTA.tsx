import React, { useState, useEffect } from 'react';
import { MessageCircle, X } from 'lucide-react';

const FloatingCTA = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 500);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToConsultation = () => {
    document.getElementById('consultation')?.scrollIntoView({ behavior: 'smooth' });
    setIsExpanded(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isExpanded && (
        <div className="mb-4 bg-primary border border-accent/20 rounded-lg p-4 shadow-lg max-w-xs">
          <div className="flex justify-between items-start mb-2">
            <h4 className="text-sm font-semibold text-accent">Ready to Transform?</h4>
            <button 
              onClick={() => setIsExpanded(false)}
              className="text-secondary/60 hover:text-secondary"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs text-secondary/80 mb-3">
            Get your free AI automation consultation and discover how much you can save.
          </p>
          <button 
            onClick={scrollToConsultation}
            className="w-full bg-accent text-primary px-3 py-2 rounded text-sm font-semibold hover:bg-accent/90 transition-colors duration-300"
          >
            Book Now
          </button>
        </div>
      )}

      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="bg-accent text-primary p-4 rounded-full shadow-lg hover:bg-accent/90 transition-all duration-300 transform hover:scale-110"
      >
        <MessageCircle className="w-6 h-6" />
      </button>
    </div>
  );
};

export default FloatingCTA;