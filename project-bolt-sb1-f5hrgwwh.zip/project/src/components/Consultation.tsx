import React, { useState } from 'react';
import { Calendar, User, Mail, Phone, Building, MessageSquare, Send } from 'lucide-react';

interface FormData {
  name: string;
  email: string;
  phone: string;
  company: string;
  industry: string;
  challenge: string;
  budget: string;
  timeline: string;
}

const Consultation = () => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    phone: '',
    company: '',
    industry: '',
    challenge: '',
    budget: '',
    timeline: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <section id="consultation" className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-accent/10 border border-accent/20 rounded-lg p-12">
            <Calendar className="w-16 h-16 text-accent mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-secondary mb-4">
              Consultation Booked Successfully!
            </h2>
            <p className="text-lg text-secondary/80 mb-6">
              Thank you for your interest in our AI automation solutions. We'll contact you within 24 hours to schedule your personalized consultation.
            </p>
            <p className="text-accent font-semibold">
              Check your email for confirmation details and next steps.
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="consultation" className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <Calendar className="w-12 h-12 text-accent mx-auto mb-4" />
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">
            Book Your Free Consultation
          </h2>
          <p className="text-lg text-secondary/80 max-w-2xl mx-auto">
            Get a personalized AI automation strategy for your business. Our experts will analyze your processes and provide a custom roadmap to success.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-secondary font-semibold mb-2">
                <User className="w-4 h-4 inline mr-2" />
                Full Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="w-full bg-secondary/5 border border-secondary/20 rounded-lg px-4 py-3 text-secondary focus:border-accent focus:outline-none transition-colors duration-300"
                placeholder="Enter your full name"
              />
            </div>

            <div>
              <label className="block text-secondary font-semibold mb-2">
                <Mail className="w-4 h-4 inline mr-2" />
                Email Address *
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="w-full bg-secondary/5 border border-secondary/20 rounded-lg px-4 py-3 text-secondary focus:border-accent focus:outline-none transition-colors duration-300"
                placeholder="Enter your email address"
              />
            </div>

            <div>
              <label className="block text-secondary font-semibold mb-2">
                <Phone className="w-4 h-4 inline mr-2" />
                Phone Number
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className="w-full bg-secondary/5 border border-secondary/20 rounded-lg px-4 py-3 text-secondary focus:border-accent focus:outline-none transition-colors duration-300"
                placeholder="Enter your phone number"
              />
            </div>

            <div>
              <label className="block text-secondary font-semibold mb-2">
                <Building className="w-4 h-4 inline mr-2" />
                Company Name *
              </label>
              <input
                type="text"
                required
                value={formData.company}
                onChange={(e) => handleInputChange('company', e.target.value)}
                className="w-full bg-secondary/5 border border-secondary/20 rounded-lg px-4 py-3 text-secondary focus:border-accent focus:outline-none transition-colors duration-300"
                placeholder="Enter your company name"
              />
            </div>

            <div>
              <label className="block text-secondary font-semibold mb-2">Industry</label>
              <select
                value={formData.industry}
                onChange={(e) => handleInputChange('industry', e.target.value)}
                className="w-full bg-secondary/5 border border-secondary/20 rounded-lg px-4 py-3 text-secondary focus:border-accent focus:outline-none transition-colors duration-300"
              >
                <option value="">Select your industry</option>
                <option value="technology">Technology</option>
                <option value="finance">Finance</option>
                <option value="healthcare">Healthcare</option>
                <option value="retail">Retail/E-commerce</option>
                <option value="manufacturing">Manufacturing</option>
                <option value="education">Education</option>
                <option value="consulting">Consulting</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-secondary font-semibold mb-2">Project Budget</label>
              <select
                value={formData.budget}
                onChange={(e) => handleInputChange('budget', e.target.value)}
                className="w-full bg-secondary/5 border border-secondary/20 rounded-lg px-4 py-3 text-secondary focus:border-accent focus:outline-none transition-colors duration-300"
              >
                <option value="">Select budget range</option>
                <option value="10k-25k">$10K - $25K</option>
                <option value="25k-50k">$25K - $50K</option>
                <option value="50k-100k">$50K - $100K</option>
                <option value="100k+">$100K+</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-secondary font-semibold mb-2">Timeline</label>
            <select
              value={formData.timeline}
              onChange={(e) => handleInputChange('timeline', e.target.value)}
              className="w-full bg-secondary/5 border border-secondary/20 rounded-lg px-4 py-3 text-secondary focus:border-accent focus:outline-none transition-colors duration-300"
            >
              <option value="">Select implementation timeline</option>
              <option value="asap">ASAP</option>
              <option value="1-3months">1-3 months</option>
              <option value="3-6months">3-6 months</option>
              <option value="6months+">6+ months</option>
            </select>
          </div>

          <div>
            <label className="block text-secondary font-semibold mb-2">
              <MessageSquare className="w-4 h-4 inline mr-2" />
              Describe Your Challenge *
            </label>
            <textarea
              required
              rows={4}
              value={formData.challenge}
              onChange={(e) => handleInputChange('challenge', e.target.value)}
              className="w-full bg-secondary/5 border border-secondary/20 rounded-lg px-4 py-3 text-secondary focus:border-accent focus:outline-none transition-colors duration-300 resize-none"
              placeholder="Tell us about your current processes and the challenges you're facing..."
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-accent text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-accent/90 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary"></div>
                <span>Submitting...</span>
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                <span>Book Free Consultation</span>
              </>
            )}
          </button>

          <p className="text-center text-sm text-secondary/60">
            By submitting this form, you agree to our Privacy Policy and Terms of Service.
          </p>
        </form>
      </div>
    </section>
  );
};

export default Consultation;