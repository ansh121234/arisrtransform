import React from 'react';
import { ArrowRight, Bot, Zap, TrendingUp } from 'lucide-react';

const Hero = () => {
  const scrollToROI = () => {
    document.getElementById('roi-calculator')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 pb-16 px-4">
      <div className="max-w-7xl mx-auto text-center">
        <div className="mb-8 flex justify-center space-x-8 opacity-60">
          <div className="animate-float">
            <Bot className="w-12 h-12 text-accent" />
          </div>
          <div className="animate-float-delayed">
            <Zap className="w-12 h-12 text-accent" />
          </div>
          <div className="animate-float-delayed-2">
            <TrendingUp className="w-12 h-12 text-accent" />
          </div>
        </div>

        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
          <span className="text-secondary">Transform Your Business with</span>
          <br />
          <span className="text-accent">AI Automation</span>
        </h1>

        <p className="text-lg md:text-xl text-secondary/80 mb-8 max-w-3xl mx-auto leading-relaxed">
          Unlock unprecedented efficiency and growth with our cutting-edge AI automation solutions. 
          Reduce costs by up to 80% while increasing productivity exponentially.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <button 
            onClick={scrollToROI}
            className="group bg-accent text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-accent/90 transition-all duration-300 transform hover:scale-105 flex items-center space-x-2"
          >
            <span>Calculate Your ROI</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
          </button>
          <button className="border border-accent text-accent px-8 py-4 rounded-lg font-semibold text-lg hover:bg-accent hover:text-primary transition-all duration-300">
            Watch Demo
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="text-center p-6 rounded-lg bg-secondary/5 backdrop-blur-sm border border-secondary/10">
            <div className="text-2xl font-bold text-accent mb-2">80%</div>
            <div className="text-secondary/80">Cost Reduction</div>
          </div>
          <div className="text-center p-6 rounded-lg bg-secondary/5 backdrop-blur-sm border border-secondary/10">
            <div className="text-2xl font-bold text-accent mb-2">500+</div>
            <div className="text-secondary/80">Processes Automated</div>
          </div>
          <div className="text-center p-6 rounded-lg bg-secondary/5 backdrop-blur-sm border border-secondary/10">
            <div className="text-2xl font-bold text-accent mb-2">24/7</div>
            <div className="text-secondary/80">AI Operations</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;