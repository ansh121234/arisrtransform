import React, { useState, useEffect } from 'react';
import { Calculator, Download, TrendingUp } from 'lucide-react';

interface ROIData {
  currentCosts: number;
  employeeHours: number;
  taskFrequency: number;
  hourlyRate: number;
}

const ROICalculator = () => {
  const [data, setData] = useState<ROIData>({
    currentCosts: 50000,
    employeeHours: 40,
    taskFrequency: 5,
    hourlyRate: 25
  });

  const [results, setResults] = useState({
    annualSavings: 0,
    roiPercentage: 0,
    paybackMonths: 0,
    efficiencyGain: 0
  });

  const calculateROI = () => {
    const annualManualCost = data.employeeHours * data.taskFrequency * 52 * data.hourlyRate;
    const totalCurrentCosts = data.currentCosts + annualManualCost;
    const automationCost = 15000; // Base automation setup cost
    const automatedCost = automationCost + (totalCurrentCosts * 0.1); // 10% of current for maintenance
    
    const annualSavings = totalCurrentCosts - automatedCost;
    const roiPercentage = ((annualSavings - automationCost) / automationCost) * 100;
    const paybackMonths = automationCost / (annualSavings / 12);
    const efficiencyGain = ((data.employeeHours * data.taskFrequency * 0.8) / (data.employeeHours * data.taskFrequency)) * 100;

    setResults({
      annualSavings: Math.max(0, annualSavings),
      roiPercentage: Math.max(0, roiPercentage),
      paybackMonths: Math.max(1, paybackMonths),
      efficiencyGain: Math.max(0, efficiencyGain)
    });
  };

  useEffect(() => {
    calculateROI();
  }, [data]);

  const handleInputChange = (field: keyof ROIData, value: number) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const exportResults = () => {
    const reportData = {
      'Current Annual Costs': `$${data.currentCosts.toLocaleString()}`,
      'Employee Hours/Week': data.employeeHours,
      'Task Frequency/Week': data.taskFrequency,
      'Hourly Rate': `$${data.hourlyRate}`,
      'Projected Annual Savings': `$${results.annualSavings.toLocaleString()}`,
      'ROI Percentage': `${results.roiPercentage.toFixed(1)}%`,
      'Payback Period': `${results.paybackMonths.toFixed(1)} months`,
      'Efficiency Gain': `${results.efficiencyGain.toFixed(1)}%`
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'roi-analysis.json';
    a.click();
  };

  return (
    <section id="roi-calculator" className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <Calculator className="w-12 h-12 text-accent" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">
            Calculate Your Automation ROI
          </h2>
          <p className="text-lg text-secondary/80 max-w-2xl mx-auto">
            Discover how much your business can save with AI automation. 
            Get instant projections based on your current operations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-6">
            <div className="bg-secondary/5 backdrop-blur-sm border border-secondary/10 rounded-lg p-6">
              <label className="block text-secondary font-semibold mb-3">
                Current Annual Process Costs ($)
              </label>
              <input
                type="range"
                min="10000"
                max="500000"
                step="5000"
                value={data.currentCosts}
                onChange={(e) => handleInputChange('currentCosts', parseInt(e.target.value))}
                className="w-full accent-accent"
              />
              <div className="flex justify-between text-sm text-secondary/60 mt-2">
                <span>$10K</span>
                <span className="text-accent font-semibold">${data.currentCosts.toLocaleString()}</span>
                <span>$500K</span>
              </div>
            </div>

            <div className="bg-secondary/5 backdrop-blur-sm border border-secondary/10 rounded-lg p-6">
              <label className="block text-secondary font-semibold mb-3">
                Employee Hours per Week
              </label>
              <input
                type="range"
                min="5"
                max="80"
                step="5"
                value={data.employeeHours}
                onChange={(e) => handleInputChange('employeeHours', parseInt(e.target.value))}
                className="w-full accent-accent"
              />
              <div className="flex justify-between text-sm text-secondary/60 mt-2">
                <span>5 hrs</span>
                <span className="text-accent font-semibold">{data.employeeHours} hrs</span>
                <span>80 hrs</span>
              </div>
            </div>

            <div className="bg-secondary/5 backdrop-blur-sm border border-secondary/10 rounded-lg p-6">
              <label className="block text-secondary font-semibold mb-3">
                Task Frequency per Week
              </label>
              <input
                type="range"
                min="1"
                max="20"
                step="1"
                value={data.taskFrequency}
                onChange={(e) => handleInputChange('taskFrequency', parseInt(e.target.value))}
                className="w-full accent-accent"
              />
              <div className="flex justify-between text-sm text-secondary/60 mt-2">
                <span>1x</span>
                <span className="text-accent font-semibold">{data.taskFrequency}x</span>
                <span>20x</span>
              </div>
            </div>

            <div className="bg-secondary/5 backdrop-blur-sm border border-secondary/10 rounded-lg p-6">
              <label className="block text-secondary font-semibold mb-3">
                Average Hourly Rate ($)
              </label>
              <input
                type="range"
                min="15"
                max="100"
                step="5"
                value={data.hourlyRate}
                onChange={(e) => handleInputChange('hourlyRate', parseInt(e.target.value))}
                className="w-full accent-accent"
              />
              <div className="flex justify-between text-sm text-secondary/60 mt-2">
                <span>$15</span>
                <span className="text-accent font-semibold">${data.hourlyRate}</span>
                <span>$100</span>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-gradient-to-br from-accent/10 to-accent/5 border border-accent/20 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <TrendingUp className="w-6 h-6 text-accent mr-2" />
                <h3 className="text-xl font-bold text-secondary">Projected Results</h3>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-primary/50 rounded-lg p-4">
                  <div className="text-2xl font-bold text-accent mb-1">
                    ${results.annualSavings.toLocaleString()}
                  </div>
                  <div className="text-sm text-secondary/80">Annual Savings</div>
                </div>
                
                <div className="bg-primary/50 rounded-lg p-4">
                  <div className="text-2xl font-bold text-accent mb-1">
                    {results.roiPercentage.toFixed(1)}%
                  </div>
                  <div className="text-sm text-secondary/80">ROI Percentage</div>
                </div>
                
                <div className="bg-primary/50 rounded-lg p-4">
                  <div className="text-2xl font-bold text-accent mb-1">
                    {results.paybackMonths.toFixed(1)}
                  </div>
                  <div className="text-sm text-secondary/80">Payback (Months)</div>
                </div>
                
                <div className="bg-primary/50 rounded-lg p-4">
                  <div className="text-2xl font-bold text-accent mb-1">
                    {results.efficiencyGain.toFixed(1)}%
                  </div>
                  <div className="text-sm text-secondary/80">Efficiency Gain</div>
                </div>
              </div>
            </div>

            <div className="text-center space-y-4">
              <button 
                onClick={exportResults}
                className="w-full bg-accent text-primary px-6 py-3 rounded-lg font-semibold hover:bg-accent/90 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2"
              >
                <Download className="w-5 h-5" />
                <span>Export Results</span>
              </button>
              
              <button 
                onClick={() => document.getElementById('consultation')?.scrollIntoView({ behavior: 'smooth' })}
                className="w-full border border-accent text-accent px-6 py-3 rounded-lg font-semibold hover:bg-accent hover:text-primary transition-all duration-300"
              >
                Get Personalized Analysis
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ROICalculator;