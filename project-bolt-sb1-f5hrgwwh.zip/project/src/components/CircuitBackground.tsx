import React from 'react';

const CircuitBackground = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      <div className="absolute inset-0 opacity-15">
        <svg 
          className="w-full h-full animate-pulse-slow"
          viewBox="0 0 100 100" 
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <pattern 
              id="circuit" 
              x="0" 
              y="0" 
              width="10" 
              height="10" 
              patternUnits="userSpaceOnUse"
            >
              <path 
                d="M5,5 L8,5 L8,2 M5,5 L2,5 L2,8 M5,5 L5,8" 
                stroke="#FFD700" 
                strokeWidth="0.2" 
                fill="none"
                opacity="0.6"
              />
              <circle 
                cx="5" 
                cy="5" 
                r="0.5" 
                fill="#FFD700" 
                opacity="0.8"
              />
              <circle 
                cx="2" 
                cy="8" 
                r="0.3" 
                fill="#FFD700" 
                opacity="0.6"
              />
              <circle 
                cx="8" 
                cy="2" 
                r="0.3" 
                fill="#FFD700" 
                opacity="0.6"
              />
            </pattern>
            <filter id="glow">
              <feGaussianBlur stdDeviation="0.5" result="coloredBlur"/>
              <feMerge> 
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <rect 
            width="100%" 
            height="100%" 
            fill="url(#circuit)" 
            filter="url(#glow)"
          />
        </svg>
      </div>
      
      <div className="absolute top-1/4 left-1/4 w-32 h-32 animate-float">
        <div className="w-full h-full border border-accent/20 rounded-full opacity-20"></div>
      </div>
      
      <div className="absolute top-3/4 right-1/4 w-24 h-24 animate-float-delayed">
        <div className="w-full h-full border border-accent/20 rounded-lg opacity-20 transform rotate-45"></div>
      </div>
      
      <div className="absolute top-1/2 right-1/3 w-16 h-16 animate-float-delayed-2">
        <div className="w-full h-full border border-accent/20 rounded-full opacity-20"></div>
      </div>
    </div>
  );
};

export default CircuitBackground;