import React from 'react';
import { Bot, Cog, Workflow, Zap, ArrowRight } from 'lucide-react';

const services = [
  {
    icon: Bot,
    title: 'Custom AI Chatbots',
    description: 'Intelligent conversational AI that handles customer inquiries, support tickets, and lead qualification 24/7.',
    features: ['Natural Language Processing', 'Multi-platform Integration', 'Advanced Analytics', 'Custom Training'],
    savings: 'Up to 70% reduction in support costs'
  },
  {
    icon: Workflow,
    title: 'Process Automation',
    description: 'Streamline repetitive tasks and complex workflows with intelligent automation that adapts to your business needs.',
    features: ['Document Processing', 'Data Entry Automation', 'Email Management', 'Report Generation'],
    savings: 'Save 30+ hours per week'
  },
  {
    icon: Cog,
    title: 'Workflow Optimization',
    description: 'Analyze and optimize your existing processes using AI-driven insights to eliminate bottlenecks and inefficiencies.',
    features: ['Process Analysis', 'Bottleneck Identification', 'Performance Metrics', 'Continuous Improvement'],
    savings: 'Increase efficiency by 85%'
  },
  {
    icon: Zap,
    title: 'Smart Integrations',
    description: 'Connect all your business tools and systems with intelligent middleware that ensures seamless data flow.',
    features: ['API Integrations', 'Real-time Sync', 'Data Transformation', 'Error Handling'],
    savings: 'Eliminate 95% of manual data entry'
  }
];

const Services = () => {
  return (
    <section id="services" className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">
            Our AI Automation Services
          </h2>
          <p className="text-lg text-secondary/80 max-w-2xl mx-auto">
            Comprehensive solutions designed to transform every aspect of your business operations
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="group bg-secondary/5 backdrop-blur-sm border border-secondary/10 rounded-lg p-8 hover:bg-secondary/10 hover:border-accent/30 transition-all duration-300 transform hover:scale-105"
            >
              <div className="flex items-center mb-6">
                <div className="bg-accent/10 p-3 rounded-lg mr-4 group-hover:bg-accent/20 transition-colors duration-300">
                  <service.icon className="w-8 h-8 text-accent" />
                </div>
                <h3 className="text-xl font-bold text-secondary">{service.title}</h3>
              </div>

              <p className="text-secondary/80 mb-6 leading-relaxed">
                {service.description}
              </p>

              <div className="mb-6">
                <h4 className="text-sm font-semibold text-accent mb-3">Key Features:</h4>
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm text-secondary/70">
                      <ArrowRight className="w-3 h-3 text-accent mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-accent/10 border border-accent/20 rounded-lg p-4 mb-6">
                <div className="text-sm font-semibold text-accent mb-1">Impact:</div>
                <div className="text-secondary font-medium">{service.savings}</div>
              </div>

              <button className="w-full bg-transparent border border-accent text-accent px-6 py-3 rounded-lg font-semibold hover:bg-accent hover:text-primary transition-all duration-300 group-hover:shadow-lg">
                Learn More
              </button>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button 
            onClick={() => document.getElementById('consultation')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-accent text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-accent/90 transition-all duration-300 transform hover:scale-105"
          >
            Get Custom Solution
          </button>
        </div>
      </div>
    </section>
  );
};

export default Services;