import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-primary/95 backdrop-blur-md border-b border-secondary/10' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 flex items-center justify-center">
              <img 
                src="/uygugygy.png" 
                alt="Arise Transform Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <span className="text-xl font-bold text-secondary">Arise Transform</span>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('home')}
              className="text-secondary hover:text-accent transition-colors duration-300"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('roi-calculator')}
              className="text-secondary hover:text-accent transition-colors duration-300"
            >
              ROI Calculator
            </button>
            <button 
              onClick={() => scrollToSection('services')}
              className="text-secondary hover:text-accent transition-colors duration-300"
            >
              Services
            </button>
            <button 
              onClick={() => scrollToSection('success-stories')}
              className="text-secondary hover:text-accent transition-colors duration-300"
            >
              Success Stories
            </button>
            <button 
              onClick={() => scrollToSection('consultation')}
              className="bg-accent text-primary px-6 py-2 rounded-lg font-semibold hover:bg-accent/90 transition-all duration-300 transform hover:scale-105"
            >
              Get Started
            </button>
          </div>

          <button 
            className="md:hidden text-secondary"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-primary/95 backdrop-blur-md border-t border-secondary/10">
          <div className="px-4 py-4 space-y-4">
            <button 
              onClick={() => scrollToSection('home')}
              className="block w-full text-left text-secondary hover:text-accent transition-colors duration-300"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('roi-calculator')}
              className="block w-full text-left text-secondary hover:text-accent transition-colors duration-300"
            >
              ROI Calculator
            </button>
            <button 
              onClick={() => scrollToSection('services')}
              className="block w-full text-left text-secondary hover:text-accent transition-colors duration-300"
            >
              Services
            </button>
            <button 
              onClick={() => scrollToSection('success-stories')}
              className="block w-full text-left text-secondary hover:text-accent transition-colors duration-300"
            >
              Success Stories
            </button>
            <button 
              onClick={() => scrollToSection('consultation')}
              className="block w-full text-left bg-accent text-primary px-4 py-2 rounded-lg font-semibold"
            >
              Get Started
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navigation;