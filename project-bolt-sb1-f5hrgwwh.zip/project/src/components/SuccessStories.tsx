import React from 'react';
import { TrendingUp, Clock, DollarSign, Users } from 'lucide-react';

const successStories = [
  {
    company: 'TechFlow Solutions',
    industry: 'Software Development',
    challenge: 'Manual code review and deployment processes taking 40+ hours weekly',
    solution: 'Automated CI/CD pipeline with AI-powered code analysis',
    results: {
      timeSaved: '35 hours/week',
      costReduction: '75%',
      efficiency: '400%',
      roi: '320%'
    },
    testimonial: "Arise Transform revolutionized our development workflow. We now deploy 10x faster with zero manual errors.",
    author: 'Sarah Chen, CTO'
  },
  {
    company: 'RetailMax',
    industry: 'E-commerce',
    challenge: 'Customer service overwhelmed with 500+ daily inquiries',
    solution: 'AI chatbot with advanced natural language processing',
    results: {
      timeSaved: '80 hours/week',
      costReduction: '65%',
      efficiency: '350%',
      roi: '280%'
    },
    testimonial: "Our customer satisfaction increased by 40% while reducing support costs significantly.",
    author: 'Michael Rodriguez, Operations Director'
  },
  {
    company: 'FinanceFirst',
    industry: 'Financial Services',
    challenge: 'Document processing and compliance reporting taking 60+ hours monthly',
    solution: 'Intelligent document automation with compliance monitoring',
    results: {
      timeSaved: '55 hours/month',
      costReduction: '70%',
      efficiency: '500%',
      roi: '450%'
    },
    testimonial: "We achieved 100% compliance accuracy while freeing up our team for strategic work.",
    author: 'Lisa Thompson, Finance Manager'
  }
];

const SuccessStories = () => {
  return (
    <section id="success-stories" className="py-20 px-4 bg-secondary/5">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">
            Client Success Stories
          </h2>
          <p className="text-lg text-secondary/80 max-w-2xl mx-auto">
            Real results from businesses that transformed their operations with our AI automation solutions
          </p>
        </div>

        <div className="space-y-8">
          {successStories.map((story, index) => (
            <div 
              key={index}
              className="bg-primary/50 backdrop-blur-sm border border-secondary/10 rounded-lg p-8 hover:border-accent/30 transition-all duration-300"
            >
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <div className="flex items-center mb-4">
                    <h3 className="text-xl font-bold text-secondary mr-4">{story.company}</h3>
                    <span className="bg-accent/20 text-accent px-3 py-1 rounded-full text-sm font-medium">
                      {story.industry}
                    </span>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div>
                      <h4 className="text-sm font-semibold text-accent mb-2">Challenge:</h4>
                      <p className="text-secondary/80">{story.challenge}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-accent mb-2">Solution:</h4>
                      <p className="text-secondary/80">{story.solution}</p>
                    </div>
                  </div>

                  <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
                    <p className="text-secondary italic mb-2">"{story.testimonial}"</p>
                    <p className="text-accent font-semibold text-sm">— {story.author}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-1 gap-4">
                  <div className="bg-secondary/5 rounded-lg p-4 text-center">
                    <Clock className="w-6 h-6 text-accent mx-auto mb-2" />
                    <div className="text-lg font-bold text-secondary">{story.results.timeSaved}</div>
                    <div className="text-sm text-secondary/70">Time Saved</div>
                  </div>
                  
                  <div className="bg-secondary/5 rounded-lg p-4 text-center">
                    <DollarSign className="w-6 h-6 text-accent mx-auto mb-2" />
                    <div className="text-lg font-bold text-secondary">{story.results.costReduction}</div>
                    <div className="text-sm text-secondary/70">Cost Reduction</div>
                  </div>
                  
                  <div className="bg-secondary/5 rounded-lg p-4 text-center">
                    <TrendingUp className="w-6 h-6 text-accent mx-auto mb-2" />
                    <div className="text-lg font-bold text-secondary">{story.results.efficiency}</div>
                    <div className="text-sm text-secondary/70">Efficiency Gain</div>
                  </div>
                  
                  <div className="bg-secondary/5 rounded-lg p-4 text-center">
                    <Users className="w-6 h-6 text-accent mx-auto mb-2" />
                    <div className="text-lg font-bold text-secondary">{story.results.roi}</div>
                    <div className="text-sm text-secondary/70">ROI</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button 
            onClick={() => document.getElementById('consultation')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-accent text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-accent/90 transition-all duration-300 transform hover:scale-105"
          >
            Start Your Success Story
          </button>
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;